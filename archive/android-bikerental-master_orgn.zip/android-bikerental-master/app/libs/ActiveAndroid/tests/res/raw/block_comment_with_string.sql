CREATE TABLE Entity1
(
	Id INTEGER AUTOINCREMENT PRIMARY KEY NOT NULL,
	Column1 INTEGER /* This is a block comment 'with a string that doesn't matter' */
)
