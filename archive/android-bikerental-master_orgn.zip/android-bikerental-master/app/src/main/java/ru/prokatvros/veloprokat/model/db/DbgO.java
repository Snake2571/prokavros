package ru.prokatvros.veloprokat.model.db;

/*
@Table(name = "DbgO")
public class DbgO extends Model {

    @Expose
    @Column(name = "id")
    public Long id;

    @Expose
    @Column(name = "Name")
    public String name;

} */
