package ru.prokatvros.veloprokat.model.db;

public class BreakdownInRent {

    public String name;

    public String phone;

    public String model;

    public int number;

}
